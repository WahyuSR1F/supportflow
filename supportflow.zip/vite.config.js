import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { handleSupportFlowApi } from './server/index';
const supportFlowApi = () => ({
    name: 'supportflow-api',
    configureServer(server) {
        server.middlewares.use(async (request, response, next) => {
            if (!request.url?.startsWith('/api/'))
                return next();
            try {
                await handleSupportFlowApi(request, response);
            }
            catch {
                if (!response.headersSent) {
                    response.statusCode = 500;
                    response.setHeader('content-type', 'application/json; charset=utf-8');
                    response.end(JSON.stringify({ error: 'Unexpected API error' }));
                }
            }
        });
    },
});
export default defineConfig({
    plugins: [react(), supportFlowApi()],
    server: {
        host: '0.0.0.0',
        allowedHosts: true,
        port: 3000,
        strictPort: true,
    },
});
