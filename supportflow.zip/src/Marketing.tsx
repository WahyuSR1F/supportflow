import { ArrowRight, Bot, Check, ChevronRight, Globe2, MessageCircle, ShieldCheck, Sparkles, UsersRound, Zap } from 'lucide-react'
import { useEffect, useState } from 'react'

type AuthMode = 'login' | 'register'

type AuthUser = {
  name?: string
  email?: string
}

const startAuth = () => {
  const redirectUri = `${window.location.origin}/manus-oauth/callback`
  window.location.assign(`/api/auth/start?redirectUri=${encodeURIComponent(redirectUri)}`)
}

export function LandingPage() {
  return <div className="marketing-shell">
    <header className="marketing-nav">
      <a className="marketing-brand" href="/" aria-label="SupportFlow home"><span className="brand-mark" aria-hidden="true"><span /><span /><i /></span><span><strong>SupportFlow</strong><small>AI support operations</small></span></a>
      <nav className="marketing-links" aria-label="Marketing navigation"><a href="#product">Product</a><a href="#how-it-works">How it works</a><a href="#security">Security</a></nav>
      <div className="marketing-actions"><a className="marketing-login" href="/login">Log in</a><a className="button button-primary marketing-cta" href="/register">Start free <ArrowRight size={15} /></a></div>
    </header>

    <main>
      <section className="marketing-hero">
        <div className="hero-copy"><span className="eyebrow compact"><span className="eyebrow-line" /> AI CUSTOMER SUPPORT, REWIRED</span><h1>Every conversation,<br /><em>handled with context.</em></h1><p>SupportFlow brings WhatsApp, Instagram, and web chat into one calm workspace — with grounded AI that knows when to answer and when to hand off.</p><div className="hero-actions"><a className="button button-primary marketing-large-cta" href="/register">Start free <ArrowRight size={16} /></a><a className="text-link" href="#product">See how it works <ChevronRight size={15} /></a></div><div className="hero-proof"><div className="proof-avatars"><span>MK</span><span>DL</span><span>SP</span><span>+2k</span></div><div><strong>Loved by support teams</strong><small>Built for fast-moving customer conversations</small></div></div></div><div className="hero-visual"><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><div className="hero-console"><div className="console-top"><span><i /> All systems operational</span><small>AI resolution 72.4%</small></div><div className="console-thread"><div className="console-side"><strong>Inbox</strong><span className="console-count">12</span><div className="console-row active"><b>MK</b><span><strong>Mira Kusuma</strong><small>Can I change my delivery address?</small></span></div><div className="console-row"><b>DL</b><span><strong>Daniel Lim</strong><small>Do you ship to Singapore?</small></span></div><div className="console-row"><b>SP</b><span><strong>Sasha Petrov</strong><small>Thanks, that solved it.</small></span></div></div><div className="console-main"><div className="console-thread-head"><div className="console-person"><b>MK</b><span><strong>Mira Kusuma</strong><small>WhatsApp · Jakarta, ID</small></span></div><span className="handoff-pill">Human handoff</span></div><div className="console-bubbles"><div className="bubble customer">Can I change the delivery address after checkout?</div><div className="bubble ai"><span><Sparkles size={11} /> SupportFlow AI</span>I can help check that. Address changes may be possible before your order ships.</div><div className="console-confidence"><span>AI suggested reply</span><strong>92%</strong><i><b /></i></div></div><div className="console-input">Ask SupportFlow AI anything <SendIcon /></div></div></div></div></div></section>

      <section className="logo-strip"><span>One workspace for your whole support stack</span><div><strong>northstar</strong><strong>BRIGHTLINE</strong><strong>HELIOS</strong><strong>COMMON GOODS</strong></div></section>

      <section className="marketing-section" id="product"><div className="section-intro"><span className="eyebrow compact">ONE OPERATING PICTURE</span><h2>Less tab-switching.<br />More helpful answers.</h2><p>Turn every customer signal into a clear next action for your team.</p></div><div className="feature-grid"><FeatureCard icon={<MessageCircle size={18} />} tone="blue" title="Unified conversations" copy="Bring WhatsApp, Instagram, and web chat into one searchable inbox." /><FeatureCard icon={<Bot size={18} />} tone="mint" title="Grounded AI replies" copy="Give agents fast drafts backed by approved knowledge, not guesswork." /><FeatureCard icon={<UsersRound size={18} />} tone="orange" title="Human when it matters" copy="Route sensitive or low-confidence moments to the right person instantly." /></div></section>

      <section className="marketing-section workflow-section" id="how-it-works"><div className="workflow-card"><div><span className="eyebrow compact">THE SUPPORTFLOW LOOP</span><h2>Calm operations,<br /><em>even at volume.</em></h2><p>SupportFlow makes the right context visible before your team sends a reply.</p><a className="text-link" href="/register">Explore the workspace <ChevronRight size={15} /></a></div><div className="workflow-steps"><Step number="01" title="Connect every channel" copy="One inbox for the conversations already happening." /><Step number="02" title="Ground every answer" copy="Approved docs keep AI precise and on-brand." /><Step number="03" title="Hand off with confidence" copy="Agents see the full thread and the why behind every suggestion." /></div></div></section>

      <section className="marketing-section security-section" id="security"><div className="security-icon"><ShieldCheck size={23} /></div><div><span className="eyebrow compact">BUILT FOR TRUST</span><h2>AI that shows its work.</h2><p>Every suggested reply can carry its sources, confidence, and handoff signal — so your team stays in control.</p></div><div className="security-points"><span><Check size={14} /> Approved knowledge only</span><span><Check size={14} /> Human handoff controls</span><span><Check size={14} /> Multi-channel audit trail</span></div></section>

      <section className="marketing-cta-section"><span className="eyebrow compact">READY WHEN YOU ARE</span><h2>Your next best reply<br /><em>is already in context.</em></h2><a className="button button-primary marketing-large-cta" href="/register">Start free <ArrowRight size={16} /></a></section>
    </main>

    <footer className="marketing-footer"><a className="marketing-brand" href="/"><span className="brand-mark" aria-hidden="true"><span /><span /><i /></span><span><strong>SupportFlow</strong><small>AI support operations</small></span></a><span>© 2024 SupportFlow. Built for better conversations.</span><div><a href="/login">Log in</a><a href="/register">Create account</a></div></footer>
  </div>
}

function FeatureCard({ icon, tone, title, copy }: { icon: React.ReactNode; tone: string; title: string; copy: string }) {
  return <article className="feature-card"><div className={`feature-icon ${tone}`}>{icon}</div><h3>{title}</h3><p>{copy}</p><a href="/register" aria-label={`Learn more about ${title}`}>Learn more <ArrowRight size={14} /></a></article>
}

function Step({ number, title, copy }: { number: string; title: string; copy: string }) {
  return <div className="workflow-step"><span>{number}</span><div><strong>{title}</strong><p>{copy}</p></div></div>
}

function SendIcon() { return <span className="send-icon"><ArrowRight size={13} /></span> }

export function AuthPage({ mode }: { mode: AuthMode }) {
  const isRegister = mode === 'register'
  return <div className="auth-shell"><div className="auth-panel"><a className="marketing-brand auth-brand" href="/"><span className="brand-mark" aria-hidden="true"><span /><span /><i /></span><span><strong>SupportFlow</strong><small>AI support operations</small></span></a><div className="auth-copy"><span className="eyebrow compact">{isRegister ? 'START YOUR WORKSPACE' : 'WELCOME BACK'}</span><h1>{isRegister ? 'Build a support team that feels one step ahead.' : 'Good support starts with the full picture.'}</h1><p>{isRegister ? 'Create your SupportFlow workspace and bring every customer conversation into context.' : 'Sign in to return to your conversations, knowledge, and AI-assisted workflows.'}</p></div><div className="auth-card"><div className="auth-card-icon"><Zap size={18} /></div><h2>{isRegister ? 'Create your account' : 'Log in to SupportFlow'}</h2><p>Use your Manus account to {isRegister ? 'create or access' : 'access'} your workspace securely.</p><button className="button button-primary auth-button" onClick={startAuth}>{isRegister ? 'Create account with Manus' : 'Continue with Manus'} <ArrowRight size={16} /></button><small className="auth-note">No separate SupportFlow password. Your account is protected by Manus OAuth.</small></div><div className="auth-switch">{isRegister ? 'Already have an account?' : 'New to SupportFlow?'} <a href={isRegister ? '/login' : '/register'}>{isRegister ? 'Log in' : 'Create an account'}</a></div></div><div className="auth-aside"><div className="auth-aside-orb" /><div className="auth-aside-content"><div className="auth-quote-mark">“</div><blockquote>SupportFlow gives our team the context to be helpful without slowing down.</blockquote><div className="quote-author"><span>MK</span><div><strong>Mira Kusuma</strong><small>Support lead · Northstar Goods</small></div></div></div><div className="auth-aside-footer"><Globe2 size={15} /> WhatsApp · Instagram · Web chat</div></div></div>
}

export function AuthCallbackPage() {
  const [message, setMessage] = useState('Completing secure sign-in…')
  useEffect(() => {
    fetch('/api/auth/session').then((response) => {
      if (response.ok) window.location.assign('/app')
      else setMessage('Sign-in could not be completed. Please return to login and try again.')
    }).catch(() => setMessage('Sign-in could not be completed. Please return to login and try again.'))
  }, [])
  return <div className="auth-callback"><div className="auth-callback-card"><div className="auth-card-icon"><Sparkles size={18} /></div><h1>SupportFlow</h1><p>{message}</p><a className="text-link" href="/login">Back to login <ArrowRight size={14} /></a></div></div>
}

export type { AuthUser }
